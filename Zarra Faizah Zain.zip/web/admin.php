<!DOCTYPE HTML PUBLIC>  
<html>  
<head>  
<title>Kerangka Web</title>  
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link href="style.css" rel="stylesheet" type="text/css"> 
</head>  
  
<body>  
<table width="900" border="0" align="center" cellpadding="0" cellspacing="0">  
  <tr bgcolor="gray">  
    <td height="100" colspan="2"></td>  
  </tr>  
  <tr bgcolor="black">  
    <td colspan="2"><marquee onmouseover="this.stop()" onmouseout="this.start()" truespeed="true" scrollamount="1" scrolldelay="40" direction="left">  
    <strong><div id="login">Selamat Datang Di Website Saya </div></strong>  
</marquee>  


</td>  
  </tr>  
  <tr>  
    <td width="200" height="600" valign="top" bgcolor="gray"><table width="200" border="0" cellspacing="0" cellpadding="0">  
      <tr>  
          
          <table width="200" border="0" cellspacing="0" cellpadding="2">  
            <tr bgcolor="#003366">  
               
              </tr>  
            <tr>  
           
              <td width="126">:   
            
            </tr>  
            <tr>  
             
              <td>:   
               
            </tr>  
            <tr>  
              <td height="30">&nbsp;</td>  
             <br>Jika Anda Ingin Logout <a href='logout.php'>Klik Di Sini</a> 
            </tr>  
          </table>  
        </form>
       </td>  
      </tr>  
      <tr>  
  
</table>  
</body>  
</html>  
