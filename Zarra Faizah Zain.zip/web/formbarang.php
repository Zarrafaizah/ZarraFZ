<html><head>
<title>Input Data Barang</title>
</head><body>
<h2>Data Barang</h2>
<form action="savebarang.php" method="POST">
<table><tr>
<td>Kode Barang</td>
<td>: <input type="text" name="kode" size="10"></td>
</tr>
<tr>
<td>Nama Barang</td>
<td>: <input type="text" name="namabarang" size="30"></td>
</tr>
<tr>
<td>Harga Satuan</td>
<td>: <input type="text" name="harga" size="20"></td>
</tr>
<tr>
<td colspan=2><input type="submit" value="Kirim"></td>
</tr></table></form>
</body></html>