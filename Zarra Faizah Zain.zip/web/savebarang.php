<?php ob_start();
include "koneksi.php";

$kode   = $_POST['kode'];
$nama   = $_POST['namabarang'];
$harga  = $_POST['harga'];

mysql_query("INSERT INTO barang(kode,namabarang,harga)
VALUE('$kode','$nama','$harga')")or die(mysql_error());
header('location:tampilbarang.php');
?>