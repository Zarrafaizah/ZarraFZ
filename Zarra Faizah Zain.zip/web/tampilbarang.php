<?php
include "koneksi.php";
include "formbarang.php";
echo "<center><table border=1><tr bgcolor=orange>
<td><b><center>No</td>
<td><b><center>Kode Barang</td>
<td><b><center>Nama Barang</td>
<td><b><center>Harga Satuan</td>
<td><b><center>Delete</td>
<td><b><center>Edit</td>
</tr>";
$query=mysql_query("SELECT * FROM barang ORDER BY kode");
$no=1;
while($var=mysql_fetch_array($query)){
echo "<tr>
<td>$no</td>
<td>$var[kode]</td>
<td>$var[namabarang]</td>
<td>$var[harga]</td>
<td><center><a href='deletebarang.php?kode=$var[kode]'>Delete</a></td>
<td><center><a href='formeditbarang.php?kode=$var[kode]'>Edit</a></center></td>
</tr>";
$no++;
}
echo "</table><br><b>Data Barang by zarra</b>";
?>