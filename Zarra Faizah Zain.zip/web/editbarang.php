<?php ob_start();
include "koneksi.php";
$kode    = $_POST['kode'];
$nama          = $_POST['namabarang'];
$harga         = $_POST['harga'];

$query=mysql_query("update barang set kode='$kode', namabarang='$nama', harga='$harga' where kode='$kode'");
header('location:tampilbarang.php');
?>